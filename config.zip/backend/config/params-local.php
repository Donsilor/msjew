<?php
return [
   'adminEmail' => 'admin@example.com',
    'adminAcronym' => 'BDD',
    'adminTitle' => 'BDD后台(本地)',
    'adminDefaultHomePage' => ['main/system'], // 默认主页

];

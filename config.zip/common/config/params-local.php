<?php
return [
    'languages'=>[
        'zh-CN'=>'简体中文',
        'en-US'=>'English',
    ],    
];

<?php
return [
      'language' =>'zh-CN',//默认语言 
];

<?php

$config = [
    'components' => [
        'request' => [
            // !!! insert a secret key in the following (if it is empty) - this is required by cookie validation
            'cookieValidationKey' => 'WFSS0jVuHUynRD3GGQ9ok6k1UK9glN9d',
        ],
    ],
];
return $config;
